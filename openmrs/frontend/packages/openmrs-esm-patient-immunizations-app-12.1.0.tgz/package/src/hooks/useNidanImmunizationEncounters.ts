import { openmrsFetch, restBaseUrl, useConfig } from '@openmrs/esm-framework';
import useSWR from 'swr';
import { type ImmunizationConfigObject } from '../config-schema';
import { mapFromNidanEncounters, type NidanEncounterResponse } from '../immunizations/nidan-mapper';

const ENCOUNTER_REPRESENTATION =
  'custom:(uuid,display,encounterDatetime,form:(uuid,name,display),' +
  'visit:(uuid,display,location:(display)),patient:(uuid),' +
  'obs:(uuid,concept:(uuid,display,conceptClass:(uuid,display)),value,obsDatetime),' +
  'encounterProviders:(provider:(person:(display))))';

/**
 * Fetches immunization data captured by the custom nidan immunization form and
 * returns it grouped by vaccine, in the same `ImmunizationGrouped[]` shape the
 * immunizations widgets already consume. This is a drop-in replacement for
 * `useImmunizations` (which reads FHIR Immunization resources) when the source
 * of truth is the nidan form encounters.
 *
 * The form UUID used to filter the nidan encounters is read from the app config
 * (`config.immunizationFormUuid`), so it is shared with the form-launch calls.
 */
export function useNidanImmunizationEncounters(patientUuid: string) {
  const { immunizationFormUuid } = useConfig<ImmunizationConfigObject>();

  const url =
    patientUuid && immunizationFormUuid
      ? `${restBaseUrl}/nidan/encounter?patient=${patientUuid}&form=${immunizationFormUuid}&v=${ENCOUNTER_REPRESENTATION}&order=desc`
      : null;

  const { data, error, isLoading, isValidating, mutate } = useSWR<{ data: NidanEncounterResponse }, Error>(
    url,
    openmrsFetch,
  );

  const existingImmunizations = data?.data?.results ? mapFromNidanEncounters(data.data.results) : [];

  return {
    data: existingImmunizations,
    error,
    isLoading,
    isValidating,
    mutate,
  };
}
