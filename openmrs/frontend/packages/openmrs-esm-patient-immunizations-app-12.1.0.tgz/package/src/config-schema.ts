import { Type } from '@openmrs/esm-framework';

export const configSchema = {
  immunizationConceptSet: {
    _type: Type.String,
    _default: 'CIEL:984',
    _description: 'A UUID or concept mapping which will have all the possible vaccines as set-members.',
  },
  immunizationFormUuid: {
    _type: Type.UUID,
    _default: '6bb5bf4c-463c-48a2-b544-91507c2a9bcd',
    _description:
      'UUID of the form used to record immunizations. Used both to launch the form entry workspace and to filter the nidan encounter data shown in the immunizations widgets.',
  },
  sequenceDefinitions: {
    _type: Type.Array,
    _elements: {
      _type: Type.Object,
      vaccineConceptUuid: {
        _type: Type.UUID,
        _description: 'The UUID of the individual vaccine concept',
      },
      sequences: {
        _type: Type.Array,
        _elements: {
          _type: Type.Object,
          sequenceLabel: {
            _type: Type.String,
            _description: 'Name of the dose/booster/schedule.. This will be used as a translation key as well.',
          },
          sequenceNumber: {
            _type: Type.Number,
            _description:
              'The dose number in the vaccines. Convention for doses is [1...9] and for boosters is [11...19]',
          },
        },
      },
    },
    _description:
      'Doses/Schedules definitions for each vaccine configured if applicable. If not provided the vaccine would be treated as a vaccine without schedules',
    _default: [
      {
        vaccineConceptUuid: '783AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
        sequences: [
          {
            sequenceLabel: 'Dose-1',
            sequenceNumber: 1,
          },
          {
            sequenceLabel: 'Dose-2',
            sequenceNumber: 2,
          },
          {
            sequenceLabel: 'Dose-3',
            sequenceNumber: 3,
          },
          {
            sequenceLabel: 'Dose-4',
            sequenceNumber: 4,
          },
          {
            sequenceLabel: 'Booster-1',
            sequenceNumber: 11,
          },
          {
            sequenceLabel: 'Booster-2',
            sequenceNumber: 12,
          },
        ],
      },
    ],
  },
};

export interface ImmunizationConfigObject {
  immunizationConceptSet: string;
  immunizationFormUuid: string;
  sequenceDefinitions: Array<{
    vaccineConceptUuid: string;
    sequences: Array<{
      sequenceLabel: string;
      sequenceNumber: number;
    }>;
  }>;
}
