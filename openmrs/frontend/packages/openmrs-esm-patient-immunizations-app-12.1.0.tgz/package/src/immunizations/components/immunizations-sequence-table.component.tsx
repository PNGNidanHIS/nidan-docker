import React, { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import {
  DataTable,
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableHeader,
  TableRow,
} from '@carbon/react';
import {
  EditIcon,
  formatDate,
  getCoreTranslation,
  showModal,
  TrashCanIcon,
  useLayoutType,
} from '@openmrs/esm-framework';
import { immunizationFormSub } from '../utils';
import { type ImmunizationGrouped } from '../../types';
import styles from './immunizations-sequence-table.scss';
interface SequenceTableProps {
  immunizationsByVaccine: ImmunizationGrouped;
  launchPatientImmunizationForm: () => void;
  patientUuid: string;
}

interface DeleteImmunizationParams {
  doseNumber: number;
  immunizationId: string;
  vaccineUuid: string;
}

const SequenceTable: React.FC<SequenceTableProps> = ({
  immunizationsByVaccine,
  launchPatientImmunizationForm,
  patientUuid,
}) => {
  const { t } = useTranslation();
  const { existingDoses, sequences, vaccineUuid } = immunizationsByVaccine;
  const isTablet = useLayoutType() === 'tablet';
  const responsiveSize = isTablet ? 'md' : 'sm';

  const tableHeaders = useMemo(
    () => [
      {
        key: 'sequence',
        header: sequences.length ? t('sequence', 'Sequence') : t('doseNumberWithinSeries', 'Dose number within series'),
      },
      { key: 'vaccinationDate', header: t('vaccinationDate', 'Vaccination date') },
      { key: 'nextDoseDate', header: t('nextDoseDate', 'Next dose date') },
      { key: 'expirationDate', header: t('expirationDate', 'Expiration date') },
      { key: 'note', header: t('note', 'Note') },
      { key: 'actions', header: t('actions', 'Actions') },
    ],
    [t, sequences.length],
  );

  const handleDeleteImmunization = ({ doseNumber, immunizationId, vaccineUuid }: DeleteImmunizationParams) => {
    const dispose = showModal('immunization-delete-confirmation-modal', {
      doseNumber,
      immunizationId,
      patientUuid,
      vaccineUuid,
      close: () => dispose?.(),
    });
  };

  const tableRows = existingDoses?.map((dose) => ({
    id: dose?.immunizationObsUuid,
    sequence: !sequences.length
      ? dose.doseNumber || 0
      : sequences?.find((s) => s.sequenceNumber === dose.doseNumber)?.sequenceLabel || dose.doseNumber,
    vaccinationDate:
      dose?.occurrenceDateTime &&
      formatDate(new Date(dose.occurrenceDateTime), {
        mode: 'standard',
        noToday: true,
        time: false,
      }),
    nextDoseDate: dose?.nextDoseDate
      ? formatDate(new Date(dose.nextDoseDate), { mode: 'standard', noToday: true, time: false })
      : '--',
    expirationDate:
      (dose?.expirationDate &&
        formatDate(new Date(dose.expirationDate), {
          mode: 'standard',
          noToday: true,
          time: false,
        })) ||
      '--',
    note: dose?.note[0]?.text || '--',
    encounterObs: dose?.encounterObs ?? [],
    actions: (
      <div className={styles.actionButtons}>
        <IconButton
          kind="ghost"
          label={getCoreTranslation('edit')}
          onClick={() => {
            immunizationFormSub.next({
              vaccineUuid: vaccineUuid,
              immunizationId: dose.immunizationObsUuid,
              vaccinationDate: dose.occurrenceDateTime,
              doseNumber: dose.doseNumber,
              nextDoseDate: dose.nextDoseDate,
              note: dose.note[0]?.text,
              expirationDate: dose.expirationDate,
              lotNumber: dose.lotNumber,
              manufacturer: dose.manufacturer,
              visitId: dose.visitUuid,
            });
            launchPatientImmunizationForm();
          }}
          size={responsiveSize}
        >
          <EditIcon size={16} />
        </IconButton>
        <IconButton
          kind="ghost"
          label={getCoreTranslation('delete')}
          onClick={() =>
            handleDeleteImmunization({
              doseNumber: dose.doseNumber,
              immunizationId: dose.immunizationObsUuid,
              vaccineUuid,
            })
          }
          size={responsiveSize}
        >
          <TrashCanIcon size={16} />
        </IconButton>
      </div>
    ),
  }));

  if (tableRows?.length) {
    // Collect unique extra obs labels across all doses for this vaccine so
    // we only show the section once (not duplicated per dose row).
    const allExtraObs = tableRows.flatMap((row) => row.encounterObs);
    const seenLabels = new Set<string>();
    const uniqueExtraObs = allExtraObs.filter((obs) => {
      if (seenLabels.has(obs.display)) return false;
      seenLabels.add(obs.display);
      return true;
    });

    return (
      <>
        <DataTable rows={tableRows} headers={tableHeaders} useZebraStyles>
          {({ rows, headers, getHeaderProps, getTableProps, getRowProps }) => (
            <TableContainer className={styles.sequenceTable}>
              <Table {...getTableProps()}>
                <TableHead>
                  <TableRow>
                    {headers.map((header) => (
                      <TableHeader {...getHeaderProps({ header })}>{header.header}</TableHeader>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((row) => {
                    return (
                      <TableRow key={row.id} {...getRowProps({ row })}>
                        {row.cells.map((cell) => (
                          <TableCell key={cell?.id} className={styles.tableCell}>
                            {cell?.value}
                          </TableCell>
                        ))}
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </DataTable>

        {uniqueExtraObs.length > 0 && (
          <div className={styles.encounterObsSection}>
            <p className={styles.encounterObsTitle}>{t('additionalDetails', 'Additional details')}</p>
            <div className={styles.encounterObsGrid}>
              {uniqueExtraObs.map((obs) => (
                <div key={obs.uuid} className={styles.encounterObsItem}>
                  <span className={styles.encounterObsLabel}>{obs.display}</span>
                  <span className={styles.encounterObsValue}>{obs.value}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </>
    );
  }
};

export default SequenceTable;
