import { orderBy } from 'lodash-es';
import { type ExistingDoses, type ExtraObs, type ImmunizationGrouped } from '../types';

/**
 * Minimal representation of the `nidan/encounter` response that the custom
 * immunization form produces. Only the fields consumed by the mapper are
 * declared here.
 */
export interface NidanObsConcept {
  uuid: string;
  display: string;
  conceptClass?: {
    uuid?: string;
    display?: string;
  };
}

export interface NidanObs {
  uuid: string;
  value: string | null;
  obsDatetime?: number | string;
  concept: NidanObsConcept;
}

export interface NidanEncounter {
  uuid: string;
  encounterDatetime: number | string;
  obs: Array<NidanObs>;
  visit?: {
    uuid?: string;
    display?: string;
    location?: { display?: string };
  };
  encounterProviders?: Array<{
    provider?: { person?: { display?: string } };
  }>;
}

export interface NidanEncounterResponse {
  results: Array<NidanEncounter>;
  totalCount?: number;
  filteredCount?: number;
}

/**
 * Concept UUID of the "Vaccination date" obs recorded by the nidan immunization
 * form. All vaccines within the same encounter share this single date obs, so
 * it is used as the `occurrenceDateTime` for every dose recorded in that
 * encounter. Falls back to `encounterDatetime` when the obs is absent.
 */
export const VACCINATION_DATE_CONCEPT_UUID = '1410AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA';

/**
 * Concept classes used to record a vaccine in the nidan immunization form.
 * Anything that is not a vaccine (vaccination date, mother's name, weight,
 * birth place, ...) is recorded under a different class (Finding/Question)
 * and is therefore ignored when building the per-vaccine dose history.
 */
const VACCINE_CONCEPT_CLASSES = new Set(['Procedure', 'Drug']);

export function isVaccineObs(obs: NidanObs): boolean {
  const className = obs?.concept?.conceptClass?.display;
  return !!className && VACCINE_CONCEPT_CLASSES.has(className);
}

/**
 * Extracts the dose number from the free-text value captured by the form
 * (e.g. "PVC-1" -> 1, "MR-0" -> 0, "IPV1" -> 1). Values that do not encode a
 * number (e.g. BCG "Yes") default to 1 so the dose is still visible.
 */
export function parseDoseNumber(value: string | null | undefined): number {
  if (value == null) {
    return 0;
  }
  const match = String(value).match(/(\d+)\s*$/);
  return match ? parseInt(match[1], 10) : 1;
}

function toIsoDate(value: number | string | undefined): string {
  if (value == null) {
    return '';
  }
  const date = typeof value === 'number' ? new Date(value) : new Date(value);
  return date.toISOString();
}

/**
 * Maps encounters produced by the custom nidan immunization form into the
 * `ImmunizationGrouped[]` shape the immunizations widgets already consume.
 *
 * All obs within one encounter were submitted together in a single form session,
 * so the "Vaccination date" obs (concept `1410AAAA…`) in that encounter is the
 * authoritative date for every vaccine recorded in the same encounter — exactly
 * the same relationship `encounterUuid` establishes in the embedded form view.
 * Falls back to `encounterDatetime` when the obs is absent.
 *
 * Manufacturer, lot number, expiration date and next-dose date are not captured
 * by the nidan form and are left empty.
 */
export function mapFromNidanEncounters(encounters: Array<NidanEncounter> | undefined | null): Array<ImmunizationGrouped> {
  if (!encounters?.length) {
    return [];
  }

  const byVaccine = new Map<string, { vaccineName: string; doses: Array<ExistingDoses> }>();

  for (const encounter of encounters) {
    // Find the single "Vaccination date" obs that the form records once per
    // encounter. All vaccines in this encounter share this date.
    const vaccinationDateObs = encounter.obs?.find(
      (obs) => obs?.concept?.uuid === VACCINATION_DATE_CONCEPT_UUID,
    );

    const occurrenceDateTime = vaccinationDateObs?.value
      ? toIsoDate(vaccinationDateObs.value)
      : toIsoDate(encounter.encounterDatetime);

    // Collect all non-vaccine obs (e.g. mother's name, father's name, weight,
    // birth place, remarks) to attach to every dose from this encounter so they
    // are visible in the expanded row of the immunizations table.
    const extraObs: Array<ExtraObs> = (encounter.obs ?? [])
      .filter((obs) => obs?.concept && !isVaccineObs(obs) && obs.concept.uuid !== VACCINATION_DATE_CONCEPT_UUID)
      .map((obs) => ({
        uuid: obs.uuid,
        display: obs.concept.display,
        value: obs.value ?? '',
      }));

    for (const obs of encounter.obs ?? []) {
      if (!obs?.concept || !isVaccineObs(obs)) {
        continue;
      }

      const vaccineUuid = obs.concept.uuid;
      if (!byVaccine.has(vaccineUuid)) {
        byVaccine.set(vaccineUuid, { vaccineName: obs.concept.display ?? vaccineUuid, doses: [] });
      }

      byVaccine.get(vaccineUuid)!.doses.push({
        immunizationObsUuid: obs.uuid,
        occurrenceDateTime,
        doseNumber: parseDoseNumber(obs.value),
        manufacturer: '',
        lotNumber: '',
        expirationDate: '',
        nextDoseDate: '',
        note: [],
        visitUuid: encounter.visit?.uuid,
        encounterObs: extraObs,
      });
    }
  }

  const groups: Array<ImmunizationGrouped> = [];
  for (const [vaccineUuid, { vaccineName, doses }] of byVaccine) {
    groups.push({
      vaccineUuid,
      vaccineName,
      existingDoses: orderBy(doses, [(dose) => dose.occurrenceDateTime], ['desc']),
    });
  }

  return orderBy(groups, [(group) => group.existingDoses[0]?.occurrenceDateTime ?? ''], ['desc']);
}
